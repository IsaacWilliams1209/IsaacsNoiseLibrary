#include "Vector2.h"
#include <math.h>

Vector2::Vector2(float xInit, float yInit)
{
	x = xInit;
	y = yInit;
}

Vector2::Vector2()
{
	x = 0;
	y = 0;
}

float Vector2::dot(Vector2 other)
{
	return (x * other.x) + (y * other.y);
}
float Vector2::distance(Vector2 other)
{
	float x2 = x - other.x;
	float y2 = y - other.y;

	x2 *= x2;
	y2 *= y2;

	return sqrtf(x2+y2);
	
}