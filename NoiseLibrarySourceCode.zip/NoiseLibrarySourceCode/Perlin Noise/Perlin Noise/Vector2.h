#pragma once
class Vector2
{
public:
	float x;
	float y;

	Vector2();
	Vector2(float x, float y);

	float dot(Vector2 other);

	float distance(Vector2 other);
};

