#pragma once
#include "Vector2.h"
#include <vector>

class PoissonDistribution
{
	
private:
	// Borders of the Generation
	int minX, minY, maxX, maxY;

	// Minimum distance between two points
	float minRadius;
	
	// Maximum distance between two points
	float maxRadius;

	// Number of attempts at adding a point
	int attemptCount = 6;

	// Attempt to add a point
	void AddPoint(Vector2 nextPoint);

public:

	// Access the points generated here
	std::vector <Vector2> points;

	PoissonDistribution(int width, int height);


};

