#pragma once
class Colour
{
public:

	// Black
	Colour();

	// Greyscale
	Colour(float grey);
	
	// RGB
	Colour(float red, float green, float blue);

	float r, g, b;
};

