#pragma once
#include "Pixel.h"
#include <vector>

class CellularNoise
{
public:
	
	// Cellular Noise with 60 randomised points
	CellularNoise(int width, int height);

	std::vector <Pixel> pixels;

};

