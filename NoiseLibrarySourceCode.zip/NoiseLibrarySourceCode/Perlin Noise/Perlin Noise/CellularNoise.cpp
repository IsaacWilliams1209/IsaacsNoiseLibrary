#include "CellularNoise.h"
#include <ctime>
#include <algorithm>
#include "PoissonDistribution.h"
// Size of the array containing the points
#define POINTSIZE 60

CellularNoise::CellularNoise(int width, int height)
{
	Pixel* points[POINTSIZE];

	// generate random points
	srand(time(NULL));
	for (int i = 0; i < POINTSIZE; i++)
	{
		points[i] = new Pixel((rand() % width), (rand() % height), Colour());
	}

	for (int x = 0; x < width; x++)
	{
		for (int y = 0; y < height; y++)
		{
			// Find the smallest distance between the position and points in the array
			float minDist = 1000;
			for (int i = 0; i < POINTSIZE; i++)
			{
				float dist = points[i]->position.distance(Vector2(x, y));
				minDist = std::min(minDist, dist);
				
			}
			pixels.push_back(Pixel(x, y, Colour(minDist)));
		}
	}
	for (int i = 0; i < POINTSIZE; i++)
	{
		delete points[i];
		points[i] = nullptr;
	}
}