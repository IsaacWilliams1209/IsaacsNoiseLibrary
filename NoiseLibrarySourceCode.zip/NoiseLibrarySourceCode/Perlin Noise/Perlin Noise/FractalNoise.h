#pragma once
#include <vector>
#include "Pixel.h"

class FractalNoise
{
public:

	std::vector <Pixel> pixels;

	// Returns colour value in 0-255 range
	FractalNoise(int width, int height, float amplitudeScale, float frequencyScale, int octaves);

	float CreateNoise(float x, float y);

private:

	float colour = 0.0f;

	int permutationTable[256];

	Vector2 gradientTable[256];

};

