#pragma once

inline float Fade(float a)
{
	return ((6 * a - 15) * a + 10) * a * a * a;
}

inline float Lerp(float transformValue, float minValue, float maxValue)
{
	return minValue + transformValue * (maxValue - minValue);
}