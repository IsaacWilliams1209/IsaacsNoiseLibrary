#include "FractalNoise.h"
#include "Maths.h"
#include <random>
#include <ctime>



FractalNoise::FractalNoise(int width, int height, float ampScale, float frequencyScale, int octaves)
{
	// Generate permutation table 
	std::vector <int> temp;
	std::default_random_engine engine((unsigned)time(NULL));
	for (int i = 0; i < 256; i++)
	{
		temp.push_back(i);
	}
	std::shuffle(temp.begin(), temp.end(), engine);
	for (int i = 0; i < 256; i++)
	{
		permutationTable[i] = temp[i];
	}

	// Generate Random gradients
	for (int i = 0; i < 256; i++)
	{
		gradientTable[i] = Vector2(float(rand()) / (RAND_MAX / 2) - 1.0f, float(rand()) / (RAND_MAX / 2) - 1.0f);
	}


	for (int y = 0; y < height; y++)
	{
		for (int x = 0; x < width; x++)
		{
			float amplitude = 1.0f;

			float frequency = 0.005f;

			for (int octave = 0; octave < octaves; octave++)
			{
				colour += amplitude * CreateNoise(x * frequency, y * frequency);

				amplitude *= ampScale;

				frequency *= frequencyScale;
			}
			colour += 1.0f;

			colour *= 0.5f;

			pixels.push_back(Pixel(x, y, Colour(colour * 255)));

		}
	}
}

float FractalNoise::CreateNoise(float x, float y)
{
	int X = (int)x % 256;
	int Y = (int)y % 256;

	// Get fractional component
	float xFrac = x - floor(x);
	float yFrac = y - floor(y);


	// Get Vectors of the grid coods containing the point
	Vector2 topRightVector = Vector2(xFrac - 1, yFrac - 1);
	Vector2 topLeftVector = Vector2(xFrac, yFrac - 1);
	Vector2 bottomRightVector = Vector2(xFrac - 1, yFrac);
	Vector2 bottomLeftVector = Vector2(xFrac, yFrac);

	// get index for gradient vectors for grid coods
	int topRightValue = permutationTable[(permutationTable[(X + 1) % 256] + Y + 1) % 256];
	int topLeftValue = permutationTable[(permutationTable[X] + Y + 1) % 256];
	int bottomRightValue = permutationTable[(permutationTable[(X + 1) % 256] + Y) % 256];
	int bottomLeftValue = permutationTable[(permutationTable[X] + Y) % 256];

	// Dot gradient vectors and grid vectors
	float dotTopRight = topRightVector.dot(gradientTable[topRightValue]);
	float dotTopLeft = topLeftVector.dot(gradientTable[topLeftValue]);
	float dotbottomRight = bottomRightVector.dot(gradientTable[bottomRightValue]);
	float dotbottomLeft = bottomLeftVector.dot(gradientTable[bottomLeftValue]);

	// interpolate between dot products to create a single float
	float fadedX = Fade(xFrac);
	float fadedY = Fade(yFrac);
	return Lerp(fadedX, Lerp(fadedY, dotbottomLeft, dotTopLeft), Lerp(fadedY, dotbottomRight, dotTopRight));
}