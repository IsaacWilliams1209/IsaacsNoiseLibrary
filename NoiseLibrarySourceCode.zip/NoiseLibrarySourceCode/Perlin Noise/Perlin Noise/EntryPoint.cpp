#include "Noisy.h"
#include "EasyBMP.hpp"
#include <iostream>
#include <string>

#define SIZE 2048

int main()
{
	FractalNoise Noise = FractalNoise( SIZE, SIZE, 1.7f, 1.0f, 8);
	EasyBMP::Image image(SIZE, SIZE, "output.bmp");

	for (int i= 0; i < Noise.pixels.size(); i++)
	{
		Vector2 position = Noise.pixels[i].position;
		Colour colour = Noise.pixels[i].colour;
		image.SetPixel(position.x, position.y, EasyBMP::RGBColor(colour.r, colour.g * 0.7f, colour.b * 0.9f));
	}
	image.Write();
	
}