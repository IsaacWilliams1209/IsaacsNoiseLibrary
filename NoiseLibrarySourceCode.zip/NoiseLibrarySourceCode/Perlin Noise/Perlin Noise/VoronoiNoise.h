#pragma once
#include <vector>
#include "Pixel.h"


class VoronoiNoise
{
public:
	// Default with eith random points or poisson for point generation and random colours
	VoronoiNoise(int width, int height, bool usePoisson);

	std::vector <Pixel> pixels;
};