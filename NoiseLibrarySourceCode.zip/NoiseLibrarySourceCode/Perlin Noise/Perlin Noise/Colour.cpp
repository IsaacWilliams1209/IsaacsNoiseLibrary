#include "Colour.h"

Colour::Colour(float rInit, float gInit, float bInit)
{
	r = rInit;
	g = gInit;
	b = bInit;
}

Colour::Colour(float grey)
{
	r = grey;
	g = grey;
	b = grey;
}

Colour::Colour()
{
	r = 0;
	g = 0;
	b = 0;
}