#include "PerlinNoise.h"
#include "Maths.h"
#include <ctime>
#include <math.h>
#include <iostream>
#include <random>

PerlinNoise::PerlinNoise(float width, float height)
{
	// Generate permutation table 
	std::vector <int> temp;
	std::default_random_engine engine((unsigned)time(NULL));
	for (int i = 0; i < 256; i++)
	{
		temp.push_back(i);
	}
	std::shuffle(temp.begin(), temp.end(), engine);
	for (int i = 0; i < 256; i++)
	{
		permutationTable[i] = temp[i];
	}

	// Generate Random gradients
	for (int i = 0; i < 256; i++)
	{
		gradientTable[i] = Vector2(float(rand()) / (RAND_MAX / 2) - 1.0f, float(rand()) / (RAND_MAX / 2) - 1.0f);
	}


	for (int y = 0; y < height; y++)
	{
		for (int x = 0; x < width; x++)
		{
			colour = CreateNoise(x*0.01, y*0.01);
			colour += 1.0f;

			colour *= 0.5f;

			pixels.push_back(Pixel(x,y, Colour(colour * 255)));
			
		}
	}

}



float PerlinNoise::CreateNoise(float x, float y)
{
	int X = (int)x % 256;
	int Y = (int)y % 256;

	// Get fractal component
	float xFrac = x - floor(x);
	float yFrac = y - floor(y);


	// Get vectors for gird coords
	Vector2 topRightVector = Vector2(xFrac - 1, yFrac - 1);
	Vector2 topLeftVector = Vector2(xFrac, yFrac - 1);
	Vector2 bottomRightVector = Vector2(xFrac - 1, yFrac);
	Vector2 bottomLeftVector = Vector2(xFrac, yFrac);

	// Get index values for grid coords
	int topRightValue = permutationTable[(permutationTable[(X + 1) % 256] + Y + 1) % 256];
	int topLeftValue = permutationTable[(permutationTable[X] + Y + 1) % 256];
	int bottomRightValue = permutationTable[(permutationTable[(X + 1) % 256] + Y )% 256];
	int bottomLeftValue = permutationTable[(permutationTable[X] + Y) % 256];

	// Dot gradient and grid vectors
	float dotTopRight = topRightVector.dot(gradientTable[topRightValue]);
	float dotTopLeft = topLeftVector.dot(gradientTable[topLeftValue]);
	float dotbottomRight = bottomRightVector.dot(gradientTable[bottomRightValue]);
	float dotbottomLeft = bottomLeftVector.dot(gradientTable[bottomLeftValue]);

	// Interpolate the dot products to get one float
	float fadedX = Fade(xFrac);
	float fadedY = Fade(yFrac);
	return Lerp(fadedX, Lerp(fadedY, dotbottomLeft, dotTopLeft), Lerp(fadedY, dotbottomRight, dotTopRight));


}