#pragma once
#include "Colour.h"
#include "Vector2.h"

class Pixel
{
public:
	Pixel(int x, int y, Colour colour);

	Pixel(Vector2 position, Colour colour);
	
	Pixel();

	Vector2 position;

	Colour colour;
};

