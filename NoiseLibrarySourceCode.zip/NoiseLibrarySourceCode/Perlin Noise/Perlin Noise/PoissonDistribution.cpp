#include "PoissonDistribution.h"
#include <ctime>
#include <iostream>

PoissonDistribution::PoissonDistribution(int width, int height)
{
	minX = 0;
	minY = 0;

	maxX = width;
	maxY = height;

	minRadius = 30;
	maxRadius = 40;

	attemptCount = 4;

	Vector2 firstPoint;
	srand(time(NULL));
	firstPoint.x = rand() % width;
	firstPoint.y = rand() % height;
	points.push_back(firstPoint);
	// While not all points have been exhausted attempt to add points
	for (int j = 0; j < points.size(); j++)
	{
		for (int i = 0; i < attemptCount; i++)
		{
			// Random angle on unit circle
			float direction = (rand() / float(RAND_MAX)) * 2.0f * 3.14159f;

			// Get distance between min and max radius
			float distance = (maxRadius - minRadius) * (rand() / float(RAND_MAX)) + minRadius;

			// Calulate offset of new point
			Vector2 offset(cos(direction) * distance, sin(direction) * distance);
			// Add the current point position to offset
			offset.x += points[j].x;
			offset.y += points[j].y;
			
			// Attempt to add the point
			AddPoint(offset);
		}
	}
}

void PoissonDistribution::AddPoint(Vector2 nextPoint)
{
	// If the point is outside the bounds do not add it
	if (nextPoint.x < minX || nextPoint.x > maxX)
	{
		return;
	}
	if (nextPoint.y < minY || nextPoint.y > maxY)
	{
		return;
	}
	for (int i = 0; i < points.size(); i++)
	{
		Vector2 displacement;
		displacement.x = points[i].x - nextPoint.x;
		displacement.y = points[i].y - nextPoint.y;
		// checks that the point is not withing the minimum radius of other points
		if (((displacement.x * displacement.x) + (displacement.y * displacement.y)) < minRadius * minRadius)
		{
			return;
		}
	}
	points.push_back(nextPoint);
}		