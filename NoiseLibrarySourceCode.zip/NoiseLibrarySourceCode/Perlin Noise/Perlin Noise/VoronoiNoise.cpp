#include "VoronoiNoise.h"
#include "Vector2.h"
#include <ctime>
#include <algorithm>
#include "PoissonDistribution.h"

VoronoiNoise::VoronoiNoise(int width, int height, bool usePoisson)
{
	std::vector <Pixel> points;
	srand(time(NULL));
	// If not using poisson then generate 30 random points with random colours
	if (!usePoisson)
	{		
		for (int i = 0; i < 30; i++)
		{
			points.push_back(Pixel((int)(rand() % width), (int)(rand() % height), Colour(rand() % 256, rand() % 256, rand() % 256)));
		}
	}
	else
	{
		
		PoissonDistribution poisson(width, height);
		points.reserve(poisson.points.size());
		for (int i = 0; i < poisson.points.size(); i++)
		{
			points.push_back(Pixel(poisson.points[i].x, poisson.points[i].y, Colour(rand() % 256, rand() % 256, rand() % 256)));
		}
	}
	

	for (int y = 0; y < height; y++)
	{
		for (int x = 0; x < width; x++)
		{
			// Find smallest distance between position and point array
			Pixel* closestPoint = &points[0];
			float minDist = 1000;
			for (int i = 0; i < points.size(); i++)
			{
				float dist = points[i].position.distance(Vector2(x, y));
				if (dist < minDist)
				{
					closestPoint = &points[i];
					minDist = dist;
				}
			}
			// put a white dot on the position of the point otherwise add the colour from the closest point 
			if (minDist < 1)
			{
				pixels.push_back(Pixel(x, y, Colour(255)));
			}
			else
				pixels.push_back(Pixel(x, y, closestPoint->colour));
			closestPoint = nullptr;
		}
	}
}