#pragma once
#include <vector>
#include "Pixel.h"

class PerlinNoise
{

	float colour = 0.0f;

	int permutationTable[256];

	Vector2 gradientTable[256];

	float CreateNoise(float x, float y);
public:

	// Returns colour values in 0-255 range
	PerlinNoise(float width, float height);

	std::vector <Pixel> pixels;

};