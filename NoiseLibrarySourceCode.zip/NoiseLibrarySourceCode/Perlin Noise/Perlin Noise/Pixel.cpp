#include "Pixel.h"

Pixel::Pixel(int xInit, int yInit, Colour colourInit)
{
	position.x = xInit;
	position.y = yInit;
	colour = colourInit;
}

Pixel::Pixel(Vector2 pos, Colour colourInit)
{
	position = pos;
	colour = colourInit;
}
